//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IK220App.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IK220TST_DIALOG             102
#define IDD_IK220APP_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_SETUP                       136
#define IDB_BITMAP1                     145
#define IDD_STATUS                      147
#define IDD_INITMSG                     148
#define IDC_Axis0                       1001
#define IDC_Axis1                       1002
#define IDC_Axis2                       1003
#define IDC_Axis3                       1004
#define IDC_Axis4                       1005
#define IDC_Axis5                       1006
#define IDC_Axis6                       1007
#define IDC_Axis7                       1008
#define IDC_START_RI                    1009
#define IDC_STOP_RI                     1010
#define IDC_START                       1011
#define IDC_STOP                        1012
#define IDC_RESET                       1013
#define IDC_RESET_RI                    1014
#define IDC_CHECK0                      1029
#define IDC_CHECK1                      1030
#define IDC_CHECK2                      1031
#define IDC_CHECK3                      1032
#define IDC_CHECK4                      1033
#define IDC_CHECK5                      1034
#define IDC_CHECK6                      1035
#define IDC_CHECK7                      1036
#define IDC_Setup                       1038
#define IDC_SIGNAL_PERIODE              1041
#define IDC_PERIOD                      1041
#define IDC_SIG_PER                     1042
#define IDC_HEADLINE                    1043
#define IDC_STATUS                      1044
#define IDC_STA1                        1046
#define IDC_STA2                        1047
#define IDC_STA3                        1048
#define IDC_STA4                        1049
#define IDC_STA5                        1050
#define IDC_STA6                        1051
#define IDC_STA7                        1052
#define IDC_STA8                        1053
#define IDC_STEXT1                      1054
#define IDC_STEXT2                      1055
#define IDC_PROGRESS1                   1055
#define IDC_STEXT3                      1056
#define IDC_COMBO1                      1056
#define IDC_STEXT4                      1057
#define IDC_Current                     1057
#define IDC_SIGNAL                      1057
#define IDC_STEXT5                      1058
#define IDC_VOLTAGE                     1058
#define IDC_SIGNAL1                     1058
#define IDC_STEXT6                      1059
#define IDC_INCREMENTAL                 1059
#define IDC_ENCODER                     1059
#define IDC_STEXT7                      1060
#define IDC_ENDAT                       1060
#define IDC_ENCODER1                    1060
#define IDC_STEXT8                      1061

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
