

// Header-File for IK220Con.cpp



#ifndef _IK220CON_H_
#define _IK220CON_H_


#include "..\include\DLLFunc.h"


#endif
			  


